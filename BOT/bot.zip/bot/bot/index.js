const fs = require('fs');
const path = require('path');
const TelegramBot = require('node-telegram-bot-api');

const avarsPath = path.join(__dirname, 'data', '.avars.json');
let avars;
try {
  avars = fs.existsSync(avarsPath)
    ? JSON.parse(fs.readFileSync(avarsPath, 'utf8'))
    : {};
} catch (err) {
  console.error('[BOT] ❌ Gagal baca .avars.json:', err.message);
  avars = {};
}

const token = process.env.TELEGRAM_BOT_TOKEN || avars.token;
if (!token) {
  console.error('[BOT] ❌ Token bot tidak ditemukan! Set TELEGRAM_BOT_TOKEN env var atau isi data/.avars.json');
  process.exit(1);
}

avars.token = token;

const db = require('./data/db');

db.ready.then(() => {
  console.log('[DB] ✅ Database siap, memulai bot...');

  const bot = new TelegramBot(token, {
    polling: {
      interval: 100,
      autoStart: true,
      params: { timeout: 30, allowed_updates: ['message', 'callback_query'] }
    }
  });

  bot.on('polling_error', (err) => {
    if (err.code === 'ETELEGRAM' && err.message?.includes('409')) {
      console.warn('[BOT] ⚠️ Polling conflict 409 — pastikan tidak ada instance lain berjalan.');
      return;
    }
    if (err.code === 'EFATAL') {
      console.error('[BOT] ❌ Fatal polling error, restarting in 5s:', err.message);
      setTimeout(() => process.exit(1), 5000);
      return;
    }
    console.error(`[BOT] ⚠️ Polling error: ${err.code} - ${err.message}`);
  });

  const { startDailyReport } = require('./services/report');
  startDailyReport(bot);

  const OWNER_ID_STR = String(avars.owner_id || '');

  const defaultCmds = [
    { command: 'start',   description: '🚀 Mulai Bot'      },
    { command: 'menu',    description: '📋 Menu Utama'     },
    { command: 'contact', description: '📞 Hubungi Admin'  },
  ];
  const adminCmds = [
    ...defaultCmds,
    { command: 'admin',   description: '🀄 Panel Admin'    },
    { command: 'cancel',  description: '❌ Batalkan Proses' },
  ];

  bot.setMyCommands(defaultCmds)
    .then(() => console.log('[BOT] ✅ Bot commands (default) set'))
    .catch(err => console.warn('[BOT] ⚠️ setMyCommands default:', err.message));

  if (OWNER_ID_STR) {
    bot.setMyCommands(adminCmds, { scope: { type: 'chat', chat_id: Number(OWNER_ID_STR) } })
      .then(() => console.log('[BOT] ✅ Bot commands (admin) set'))
      .catch(err => console.warn('[BOT] ⚠️ setMyCommands admin:', err.message));
  }

  console.log(`\n[${avars.bot_name || 'BOT'}] ✅ Status: Online 🚀`);

  if (avars.owner_id) {
    db.run(
      "INSERT OR IGNORE INTO users (chat_id, saldo, role, created_at) VALUES (?, 0, 'admin', datetime('now','localtime'))",
      [String(avars.owner_id)],
      () => {
        db.run("UPDATE users SET role='admin' WHERE chat_id=? AND role != 'admin'", [String(avars.owner_id)]);
      }
    );
  }

  try {
    const admin = require('./cmd/admin');
    admin(bot);
    console.log('[BOT] ✅ Admin panel aktif');
  } catch (err) {
    console.error('[BOT] ❌ Gagal load admin:', err.message);
  }

  try {
    const runHandler = require('./handler');
    runHandler(bot);
    console.log('[BOT] ✅ Handler loaded');
  } catch (err) {
    console.error('[BOT] ❌ Gagal load handler:', err.message);
  }

  try {
    const { startPaymentChecker } = require('./services/paymentChecker');
    startPaymentChecker(bot);
    console.log('[BOT] ✅ Payment checker aktif');
  } catch (err) {
    console.error('[BOT] ❌ Gagal start payment checker:', err.message);
  }

  try {
    const { startExpiredNotif } = require('./services/expiredNotif');
    startExpiredNotif(bot);
    console.log('[BOT] ✅ Expired notif aktif');
  } catch (err) {
    console.error('[BOT] ❌ Gagal start expired notif:', err.message);
  }

  try {
    const { startAutoDelete } = require('./services/autoDelete');
    startAutoDelete(bot);
    console.log('[BOT] ✅ Auto-delete akun expired aktif');
  } catch (err) {
    console.error('[BOT] ❌ Gagal start auto-delete:', err.message);
  }

  console.log('[BOT] 🚀 Bot running, siap melayani order!\n');

}).catch(err => {
  console.error('[DB] ❌ Gagal init database:', err.message);
  process.exit(1);
});

process.on('uncaughtException', (err) => {
  console.error('[BOT] 🔥 Uncaught Exception:', err.stack || err.message);
});

process.on('unhandledRejection', (reason) => {
  console.error('[BOT] 🔥 Unhandled Rejection:', reason?.stack || reason);
});
