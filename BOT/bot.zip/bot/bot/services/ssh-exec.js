// services/ssh-exec.js - v4.0 — API mode + SSH fallback, retry, autoMenu
'use strict';

let Client;
try { Client = require('ssh2').Client; } catch { Client = null; }
const http    = require('http');
const https   = require('https');
const db      = require('../data/db');
const fs      = require('fs');
const path    = require('path');
const { autoMenu } = require('../utils/autoMenu');

function formatRupiah(n) { return 'Rp ' + Number(n).toLocaleString('id-ID'); }

function getServers() {
  try {
    const p = require.resolve('../data/server');
    delete require.cache[p];
    return require('../data/server');
  } catch (e) { return []; }
}

/* Bersihkan noise dari output SSH */
function cleanOutput(raw) {
  return (raw || '')
    .split('\n')
    .filter(l => {
      const t = l.trim();
      if (!t) return false;
      if (/TERM environment/i.test(t)) return false;
      if (/tput:/i.test(t))            return false;
      if (/setlocale/i.test(t))        return false;
      if (/cannot change locale/i.test(t)) return false;
      if (/^bash:.*warning:/i.test(t)) return false;
      return true;
    })
    .join('\n')
    .trim();
}

function buildProgress(pct, label) {
  const total  = 10;
  const filled = Math.round(pct / 10);
  const bar    = '▰'.repeat(filled) + '▱'.repeat(total - filled);
  return `${label}\n<code>${bar}</code>  <b>${pct}%</b>`;
}

const MAX_SSH_RETRIES = 2;
const RETRYABLE_PATTERNS = [
  /timeout/i,
  /ECONNREFUSED/,
  /ECONNRESET/,
  /ETIMEDOUT/,
  /socket hang up/i,
  /connection.*reset/i,
  /read ECONNRESET/i
];

function isRetryableError(err) {
  const msg = err.message || '';
  return RETRYABLE_PATTERNS.some(p => p.test(msg));
}

function executeViaAPI(serverConfig, scriptFileName, args, callback) {
  const apiUrl  = serverConfig.apiUrl;
  const apiToken = serverConfig.apiToken;

  const postData = JSON.stringify({ script: scriptFileName, args: args.map(String), token: apiToken });
  const url = new URL(apiUrl + '/api/exec');
  const isHttps = url.protocol === 'https:';
  const transport = isHttps ? https : http;

  const options = {
    hostname: url.hostname,
    port:     url.port || (isHttps ? 443 : 80),
    path:     url.pathname,
    method:   'POST',
    headers:  {
      'Content-Type':  'application/json',
      'Content-Length': Buffer.byteLength(postData),
      'X-Api-Token':   apiToken
    },
    timeout: 35000
  };

  const req = transport.request(options, (res) => {
    let body = '';
    res.on('data', chunk => { body += chunk; });
    res.on('end', () => {
      try {
        const json = JSON.parse(body);
        if (res.statusCode === 401) {
          return callback(new Error('API Token tidak valid'));
        }
        if (res.statusCode === 404) {
          return callback(new Error(`Script "${scriptFileName}" tidak ditemukan di server`));
        }
        if (json.error === 'TIMEOUT') {
          return callback(new Error('Script timeout (30 detik)'));
        }
        if (json.exitCode && json.exitCode !== 0) {
          return callback(new Error(json.output || `Script gagal dengan exit code ${json.exitCode}`));
        }
        callback(null, json.output || '');
      } catch (e) {
        callback(new Error('Respons API tidak valid: ' + body.slice(0, 200)));
      }
    });
  });

  req.on('timeout', () => {
    req.destroy();
    callback(new Error('Koneksi API timeout (35 detik)'));
  });

  req.on('error', (err) => {
    callback(new Error('Gagal menghubungi API server: ' + err.message));
  });

  req.write(postData);
  req.end();
}

function executeScriptRemote(serverIp, scriptFileName, args, callback) {
  const servers      = getServers();
  const serverConfig = servers.find(s => s.ip === serverIp);
  if (!serverConfig) return callback(new Error(`Server ${serverIp} tidak terdaftar`));

  if (serverConfig.apiUrl && serverConfig.apiToken) {
    console.log(`[SSH] Menggunakan API mode untuk ${serverIp}`);
    return executeViaAPI(serverConfig, scriptFileName, args, callback);
  }

  if (!Client) {
    return callback(new Error('SSH tidak tersedia. Pastikan server dikonfigurasi dengan apiUrl & apiToken untuk mode API.'));
  }

  const scriptPath = path.join(__dirname, '..', 'shell_script', scriptFileName);
  if (!fs.existsSync(scriptPath)) return callback(new Error(`Script ${scriptFileName} tidak ditemukan`));

  const scriptContent = fs.readFileSync(scriptPath, 'utf8');

  let done = false;
  function finish(err, result) {
    if (done) return;
    done = true;
    callback(err, result);
  }

  function attempt(retryCount) {
    const conn = new Client();

    const safeArgs = args.map(a => String(a).replace(/'/g, "'\\''"));
    const isRoot   = (serverConfig.username || 'root') === 'root';
    const tmpFile  = `/tmp/_bot_${Date.now()}`;
    const runCmd   = isRoot
      ? `bash ${tmpFile} ${safeArgs.join(' ')}`
      : `echo '${(serverConfig.pass || '').replace(/'/g, "'\\''")}' | sudo -S bash ${tmpFile} ${safeArgs.join(' ')}`;
    const command  = `cat > ${tmpFile} && ${runCmd}; __exit=$?; rm -f ${tmpFile}; exit $__exit`;

    let settled = false;

    const TIMEOUT = setTimeout(() => {
      if (settled) return;
      settled = true;
      conn.end();
      if (retryCount < MAX_SSH_RETRIES) {
        console.log(`[SSH] Timeout ke ${serverIp}, retry ${retryCount + 1}/${MAX_SSH_RETRIES}...`);
        return attempt(retryCount + 1);
      }
      finish(new Error('Koneksi SSH timeout (30 detik)'));
    }, 30000);

    conn.on('ready', () => {
      conn.exec(command, (err, stream) => {
        if (err) {
          if (settled) return;
          settled = true;
          clearTimeout(TIMEOUT);
          conn.end();
          return finish(err);
        }

        let output = '';
        stream.on('data', data => { output += data; });
        stream.stderr.on('data', data => {
          const line = data.toString();
          if (!line.includes('[sudo]') && !line.includes('password for')) output += line;
        });
        stream.on('close', (code) => {
          if (settled) return;
          settled = true;
          clearTimeout(TIMEOUT);
          conn.end();
          const finalOutput = output.trim();
          if (code && code !== 0) {
            return finish(new Error(finalOutput || `Script gagal dengan exit code ${code}`));
          }
          finish(null, finalOutput);
        });
        stream.end(scriptContent);
      });
    })
    .on('keyboard-interactive', (_n, _i, _l, prompts, finishAuth) => {
      finishAuth(prompts.map(() => serverConfig.pass));
    })
    .on('error', err => {
      if (settled) return;
      settled = true;
      clearTimeout(TIMEOUT);
      if (isRetryableError(err) && retryCount < MAX_SSH_RETRIES) {
        console.log(`[SSH] Error ke ${serverIp}: ${err.message}, retry ${retryCount + 1}/${MAX_SSH_RETRIES}...`);
        return attempt(retryCount + 1);
      }
      finish(err);
    })
    .connect({
      host:         serverIp,
      port:         22,
      username:     serverConfig.username || 'root',
      password:     serverConfig.pass,
      tryKeyboard:  true,
      readyTimeout: 25000
    });
  }

  attempt(0);
}

function increaseServerUsage(serverIp) {
  const servers = getServers();
  const server  = servers.find(s => s.ip === serverIp);
  if (!server) return;
  server.used  = (server.used || 0) + 1;
  server.limit = server.limit || 999;
  const file = path.join(__dirname, '../data/server.js');
  fs.writeFileSync(file, `const servers = ${JSON.stringify(servers, null, 2)};\n\nmodule.exports = servers;`);
}

function doCreateAccountAfterPayment(bot, chatId, accountCreate) {
  const { type, serverIp, data, scriptName, productType, label, role, totalHarga, pricePerDay } = accountCreate;

  let args = [];
  if (type === 'ssh')   args = [data.username, data.password, data.limitIp, data.days];
  else if (['vmess', 'vless', 'trojan'].includes(type)) args = [data.username, data.days, data.quota ?? 1, data.limitIp];
  else if (type === 'zivpn') args = [data.password, data.days, data.limitIp];

  /* Kirim pesan loading dengan progress bar */
  bot.sendMessage(chatId,
    buildProgress(0, `⏳ <b>Pembayaran diterima!</b>\nMembuat akun <b>${label}</b>...`),
    { parse_mode: 'HTML' }
  ).then(loadMsg => {
    const msgId     = loadMsg?.message_id;
    let animStep    = 1;
    const FRAMES = [
      { pct: 30, label: `🔄 <b>Membuat akun ${label}...</b>` },
      { pct: 60, label: '⚙️ <b>Mengonfigurasi protokol...</b>' },
      { pct: 70, label: '📝 <b>Menyimpan konfigurasi...</b>'   }
    ];

    const animInterval = setInterval(() => {
      if (animStep - 1 < FRAMES.length && msgId) {
        const f = FRAMES[animStep - 1];
        bot.editMessageText(buildProgress(f.pct, f.label), {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML'
        }).catch(() => {});
        animStep++;
      }
    }, 2500);

    executeScriptRemote(serverIp, scriptName, args, (err, rawOutput) => {
      clearInterval(animInterval);
      const output = cleanOutput(rawOutput);

      if (err) {
        console.error('[doCreateAccountAfterPayment] ❌', err.message);
        const errText = `❌ Pembayaran diterima, tapi gagal buat akun.\n\n<code>${err.message}</code>\n\nHubungi admin untuk tindak lanjut.`;
        if (msgId) bot.editMessageText(errText, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }).catch(() => bot.sendMessage(chatId, errText, { parse_mode: 'HTML' }));
        else bot.sendMessage(chatId, errText, { parse_mode: 'HTML' });
        return;
      }

      if (!/RESULT_START[\s\S]*RESULT_END/.test(output || '')) {
        console.error('[doCreateAccountAfterPayment] ❌ No RESULT block in output');
        const errText = `❌ Pembayaran diterima, tapi akun gagal dibuat.\n\n<code>${output || 'Output script kosong'}</code>\n\nHubungi admin untuk tindak lanjut.`;
        if (msgId) bot.editMessageText(errText, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }).catch(() => bot.sendMessage(chatId, errText, { parse_mode: 'HTML' }));
        else bot.sendMessage(chatId, errText, { parse_mode: 'HTML' });
        return;
      }

      const expiredAt = new Date(Date.now() + data.days * 86400000)
        .toISOString().slice(0, 19).replace('T', ' ');
      const username = data.username || data.password || '-';

      db.run(
        "INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type, username, expired_at, server_ip) VALUES (?, ?, ?, 'completed', datetime('now','localtime'), ?, ?, ?, ?)",
        [chatId, `${productType}-${Date.now()}`, totalHarga, productType, username, expiredAt, serverIp]
      );

      increaseServerUsage(serverIp);

      const detailText =
        `✅ <b>${label.toUpperCase()} BERHASIL DIBUAT!</b>\n\n` +
        (output ? `<pre>${output}</pre>\n\n` : '') +
        `💰 Harga/Hari : ${formatRupiah(pricePerDay)}\n` +
        `📅 Masa Aktif : ${data.days} hari\n` +
        `🧮 Total      : ${formatRupiah(totalHarga)}`;

      const doneKeyboard = { inline_keyboard: [[{ text: '🔃 Menu Utama', callback_data: 'menu_back' }]] };

      const edit100 = msgId
        ? bot.editMessageText(buildProgress(100, `✅ <b>${label.toUpperCase()} BERHASIL!</b>`), { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' })
        : Promise.resolve();

      edit100.catch(() => {}).finally(() => {
        setTimeout(() => {
          const showDetail = msgId
            ? bot.editMessageText(detailText, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML', reply_markup: doneKeyboard })
            : bot.sendMessage(chatId, detailText, { parse_mode: 'HTML', reply_markup: doneKeyboard });

          showDetail.catch(() => bot.sendMessage(chatId, detailText, { parse_mode: 'HTML', reply_markup: doneKeyboard }).catch(() => {}));
          autoMenu(bot, chatId, 1500);
        }, 800);
      });
    });
  }).catch(err => {
    console.error('[doCreateAccountAfterPayment] sendMessage error:', err.message);
    /* Fallback tanpa progress */
    executeScriptRemote(serverIp, scriptName, args, (err2, rawOutput) => {
      if (err2) return bot.sendMessage(chatId, `❌ Gagal buat akun: ${err2.message}`, { parse_mode: 'HTML' });
      const output = cleanOutput(rawOutput);
      if (!/RESULT_START[\s\S]*RESULT_END/.test(output || '')) {
        return bot.sendMessage(chatId, `❌ Gagal buat akun.\n\n<code>${output || 'Output kosong'}</code>\n\nHubungi admin.`, { parse_mode: 'HTML' });
      }
      bot.sendMessage(chatId,
        `✅ <b>${label.toUpperCase()} BERHASIL DIBUAT!</b>\n\n` + (output ? `<pre>${output}</pre>` : ''),
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🔃 Menu Utama', callback_data: 'menu_back' }]] } }
      ).catch(() => {});
      autoMenu(bot, chatId, 1500);
    });
  });
}

function doRenewAccountAfterPayment(bot, chatId, accountRenew) {
  const { account, data, scriptName, label, totalHarga, pricePerDay } = accountRenew;

  let args = [];
  if (account.product_type === 'SSH')   args = [account.username, data.days, data.limitIp];
  else if (['VMESS', 'VLESS', 'TROJAN'].includes(account.product_type)) args = [account.username, data.days, data.quota ?? 1, data.limitIp];
  else if (account.product_type === 'ZIVPN') args = [account.username, data.days, data.limitIp];

  bot.sendMessage(chatId,
    buildProgress(0, `⏳ <b>Pembayaran diterima!</b>\nMeng-extend akun <b>${account.username}</b>...`),
    { parse_mode: 'HTML' }
  ).then(loadMsg => {
    const msgId  = loadMsg?.message_id;
    let animStep = 1;
    const FRAMES = [
      { pct: 30, label: `🔄 <b>Memperpanjang ${account.username}...</b>` },
      { pct: 60, label: '⚙️ <b>Memperbarui konfigurasi...</b>'           },
      { pct: 70, label: '📝 <b>Menyimpan perubahan...</b>'               }
    ];

    const animInterval = setInterval(() => {
      if (animStep - 1 < FRAMES.length && msgId) {
        const f = FRAMES[animStep - 1];
        bot.editMessageText(buildProgress(f.pct, f.label), {
          chat_id: chatId, message_id: msgId, parse_mode: 'HTML'
        }).catch(() => {});
        animStep++;
      }
    }, 2500);

    executeScriptRemote(account.server_ip, scriptName, args, (err, rawOutput) => {
      clearInterval(animInterval);
      const output = cleanOutput(rawOutput);

      if (err) {
        console.error('[doRenewAccountAfterPayment] ❌', err.message);
        const errText = `❌ Pembayaran diterima, tapi gagal extend.\n\n<code>${err.message}</code>\n\nHubungi admin.`;
        if (msgId) bot.editMessageText(errText, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }).catch(() => bot.sendMessage(chatId, errText, { parse_mode: 'HTML' }));
        else bot.sendMessage(chatId, errText, { parse_mode: 'HTML' });
        return;
      }

      if (!/RESULT_START[\s\S]*RESULT_END/.test(output || '')) {
        console.error('[doRenewAccountAfterPayment] ❌ No RESULT block in output');
        const errText = `❌ Pembayaran diterima, tapi extend gagal.\n\n<code>${output || 'Output script kosong'}</code>\n\nHubungi admin.`;
        if (msgId) bot.editMessageText(errText, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }).catch(() => bot.sendMessage(chatId, errText, { parse_mode: 'HTML' }));
        else bot.sendMessage(chatId, errText, { parse_mode: 'HTML' });
        return;
      }

      const expiredAt = new Date(Date.now() + data.days * 86400000)
        .toISOString().slice(0, 19).replace('T', ' ');

      db.run(
        "INSERT INTO transactions (chat_id, order_id, amount, status, created_at, product_type, username, expired_at, server_ip) VALUES (?, ?, ?, 'completed', datetime('now','localtime'), ?, ?, ?, ?)",
        [chatId, `RENEW-${account.product_type}-${Date.now()}`, totalHarga,
         `RENEW ${account.product_type}`, account.username, expiredAt, account.server_ip]
      );

      const detailText =
        `✅ <b>EXTEND ${account.product_type} BERHASIL!</b>\n\n` +
        (output ? `<pre>${output}</pre>\n\n` : '') +
        `🆔 Username : ${account.username}\n` +
        `📅 Extend   : ${data.days} hari\n` +
        `🧮 Total    : ${formatRupiah(totalHarga)}`;

      const doneKeyboard = { inline_keyboard: [[{ text: '🔃 Menu Utama', callback_data: 'menu_back' }]] };

      const edit100 = msgId
        ? bot.editMessageText(buildProgress(100, `✅ <b>EXTEND BERHASIL!</b>`), { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' })
        : Promise.resolve();

      edit100.catch(() => {}).finally(() => {
        setTimeout(() => {
          const showDetail = msgId
            ? bot.editMessageText(detailText, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML', reply_markup: doneKeyboard })
            : bot.sendMessage(chatId, detailText, { parse_mode: 'HTML', reply_markup: doneKeyboard });

          showDetail.catch(() => bot.sendMessage(chatId, detailText, { parse_mode: 'HTML', reply_markup: doneKeyboard }).catch(() => {}));
          autoMenu(bot, chatId, 1500);
        }, 800);
      });
    });
  }).catch(err => {
    console.error('[doRenewAccountAfterPayment] sendMessage error:', err.message);
    executeScriptRemote(account.server_ip, scriptName, args, (err2, rawOutput) => {
      if (err2) return bot.sendMessage(chatId, `❌ Gagal extend: ${err2.message}`, { parse_mode: 'HTML' });
      const output = cleanOutput(rawOutput);
      if (!/RESULT_START[\s\S]*RESULT_END/.test(output || '')) {
        return bot.sendMessage(chatId, `❌ Gagal extend akun.\n\n<code>${output || 'Output kosong'}</code>\n\nHubungi admin.`, { parse_mode: 'HTML' });
      }
      bot.sendMessage(chatId,
        `✅ <b>EXTEND ${account.product_type} BERHASIL!</b>\n\n` + (output ? `<pre>${output}</pre>` : ''),
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🔃 Menu Utama', callback_data: 'menu_back' }]] } }
      ).catch(() => {});
      autoMenu(bot, chatId, 1500);
    });
  });
}

module.exports = {
  executeScriptRemote,
  increaseServerUsage,
  doCreateAccountAfterPayment,
  doRenewAccountAfterPayment
};
