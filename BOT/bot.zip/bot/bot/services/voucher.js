// services/voucher.js — Generate & Claim Voucher Saldo
'use strict';

const db = require('../data/db');

/* ── DB helpers ── */
function runAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) { if (err) return reject(err); resolve(this); });
  });
}
function getAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => { if (err) return reject(err); resolve(row || null); });
  });
}
function allAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => { if (err) return reject(err); resolve(rows || []); });
  });
}

/* ── Pastikan tabel ada ── */
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS vouchers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE NOT NULL,
    saldo INTEGER NOT NULL,
    max_claims INTEGER NOT NULL DEFAULT 1,
    claimed_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now','localtime')),
    is_active INTEGER NOT NULL DEFAULT 1
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS voucher_claims (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    voucher_code TEXT NOT NULL,
    chat_id INTEGER NOT NULL,
    claimed_at TEXT DEFAULT (datetime('now','localtime')),
    UNIQUE(voucher_code, chat_id)
  )`);
});

/* ── Generate kode random yan_{7-8 char} ── */
function generateCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const len   = Math.random() < 0.5 ? 7 : 8;
  let code    = '';
  for (let i = 0; i < len; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return `yan_${code}`;
}

/* ── Buat voucher baru ── */
async function createVoucher(saldo, maxClaims) {
  let code, attempts = 0;
  while (attempts < 10) {
    code = generateCode();
    const existing = await getAsync('SELECT id FROM vouchers WHERE code=?', [code]);
    if (!existing) break;
    attempts++;
  }
  await runAsync(
    `INSERT INTO vouchers (code, saldo, max_claims) VALUES (?, ?, ?)`,
    [code, saldo, maxClaims]
  );
  return code;
}

/* ── Claim voucher oleh user ── */
async function claimVoucher(code, chatId) {
  const normalizedCode = code.trim().toUpperCase();
  const voucher = await getAsync('SELECT * FROM vouchers WHERE UPPER(code)=?', [normalizedCode]);

  if (!voucher)              return { ok: false, reason: 'not_found' };
  if (!voucher.is_active)    return { ok: false, reason: 'inactive' };
  if (voucher.claimed_count >= voucher.max_claims) return { ok: false, reason: 'exhausted' };

  const alreadyClaimed = await getAsync(
    'SELECT id FROM voucher_claims WHERE voucher_code=? AND chat_id=?',
    [voucher.code, chatId]
  );
  if (alreadyClaimed) return { ok: false, reason: 'already_claimed' };

  await runAsync('INSERT INTO voucher_claims (voucher_code, chat_id) VALUES (?, ?)', [voucher.code, chatId]);
  await runAsync('UPDATE vouchers SET claimed_count=claimed_count+1 WHERE code=?', [voucher.code]);

  const newCount = voucher.claimed_count + 1;
  if (newCount >= voucher.max_claims) {
    await runAsync('UPDATE vouchers SET is_active=0 WHERE code=?', [voucher.code]);
  }

  await runAsync(
    "INSERT OR IGNORE INTO users (chat_id, saldo, role, created_at) VALUES (?, 0, 'members', datetime('now','localtime'))",
    [chatId]
  );
  await runAsync('UPDATE users SET saldo=saldo+? WHERE chat_id=?', [voucher.saldo, chatId]);

  const userRow = await getAsync('SELECT saldo FROM users WHERE chat_id=?', [chatId]);

  return {
    ok: true,
    saldo: voucher.saldo,
    newSaldo: userRow?.saldo || voucher.saldo
  };
}

/* ── Daftar voucher aktif ── */
async function listVouchers() {
  return allAsync('SELECT * FROM vouchers ORDER BY created_at DESC LIMIT 20');
}

/* ── Nonaktifkan voucher ── */
async function deactivateVoucher(code) {
  return runAsync('UPDATE vouchers SET is_active=0 WHERE code=?', [code]);
}

module.exports = { createVoucher, claimVoucher, listVouchers, deactivateVoucher };
